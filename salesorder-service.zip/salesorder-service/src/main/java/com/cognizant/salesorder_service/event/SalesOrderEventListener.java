package com.cognizant.salesorder_service.event;


import org.springframework.context.ApplicationListener;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;


@Component
public class SalesOrderEventListener {

	@EventListener
    public void onSalesOrderCreated(SalesOrderCreatedEvent event) {
        System.out.println("New order created: " + event.getSalesOrder().getId());
    }
}