package com.cognizant.item_service.service;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cognizant.item_service.event.ItemCreatedEvent;
import com.cognizant.item_service.model.Item;
import com.cognizant.item_service.repository.ItemRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ItemService {

    private final ItemRepository itemRepository;
    private final ApplicationEventPublisher applicationEventPublisher;
    private final RestTemplate restTemplate;

    public Item saveItem(Item item) {
    	System.out.println(item.getName());
        Item savedItem = itemRepository.save(item);
        applicationEventPublisher.publishEvent(new ItemCreatedEvent(savedItem));

        return savedItem;
    }

    public Item getItemByName(String name) {
        return itemRepository.findByName(name);
    }
}
