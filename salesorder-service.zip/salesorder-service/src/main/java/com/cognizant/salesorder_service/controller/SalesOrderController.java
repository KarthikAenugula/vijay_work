package com.cognizant.salesorder_service.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cognizant.salesorder_service.model.SalesOrder;
import com.cognizant.salesorder_service.service.SalesOrderService;

import java.util.List;

@RestController
@RequestMapping("/sales-orders")
public class SalesOrderController {

    @Autowired
    private SalesOrderService salesOrderService;

    @GetMapping
    public ResponseEntity<List<SalesOrder>> getAllSalesOrders() {
        return ResponseEntity.ok(salesOrderService.getAllSalesOrders());
    }

    @PostMapping
    public ResponseEntity<SalesOrder> createSalesOrder(@RequestBody SalesOrder salesOrder) {
        return ResponseEntity.ok(salesOrderService.createSalesOrder(salesOrder));
    }
    
    @GetMapping("/{id}")
    public SalesOrder getOrder(@PathVariable Long id) {
        return salesOrderService.getOrder(id);
    }
}
