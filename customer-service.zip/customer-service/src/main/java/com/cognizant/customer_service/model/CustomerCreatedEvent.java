package com.cognizant.customer_service.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CustomerCreatedEvent {

    private final Customer customer;
}