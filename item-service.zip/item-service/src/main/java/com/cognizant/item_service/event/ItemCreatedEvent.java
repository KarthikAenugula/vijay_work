package com.cognizant.item_service.event;

import org.springframework.context.ApplicationEvent;

import com.cognizant.item_service.model.Item;

public class ItemCreatedEvent extends ApplicationEvent {

    private final Item item;

    public ItemCreatedEvent(Item item) {
        super(item);
        this.item = item;
    }

    public Item getItem() {
        return item;
    }
}