package com.cognizant.salesorder_service.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import com.cognizant.salesorder_service.event.SalesOrderCreatedEvent;
import com.cognizant.salesorder_service.model.SalesOrder;
import com.cognizant.salesorder_service.repository.SalesOrderRepository;

import jakarta.transaction.Transactional;

import java.util.List;

@Service
public class SalesOrderService {

    @Autowired
    private SalesOrderRepository salesOrderRepository;

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    public List<SalesOrder> getAllSalesOrders() {
        return salesOrderRepository.findAll();
    }

    @Transactional
    public SalesOrder createSalesOrder(SalesOrder salesOrder) {
        SalesOrder savedSalesOrder = salesOrderRepository.save(salesOrder);
        eventPublisher.publishEvent(new SalesOrderCreatedEvent(savedSalesOrder)); // Publish event
        return savedSalesOrder;
    }
}

