package com.cognizant.customer_service.service;


import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import com.cognizant.customer_service.event.CustomerCreatedEvent;
import com.cognizant.customer_service.model.Customer;
import com.cognizant.customer_service.repository.CustomerRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomerService {

	private final CustomerRepository customerRepository;
    private final ApplicationEventPublisher applicationEventPublisher;

    public Customer saveCustomer(Customer customer) {
        Customer savedCustomer = customerRepository.save(customer);
        applicationEventPublisher.publishEvent(new CustomerCreatedEvent(savedCustomer));
        return savedCustomer;
    }

    public Customer getCustomer(Long id) {
        return customerRepository.findById(id).orElse(null);
    }
}
