package com.cognizant.customer_service.event;

import org.springframework.context.ApplicationEvent;

import com.cognizant.customer_service.model.Customer;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
public class CustomerCreatedEvent extends ApplicationEvent {

    private final Customer customer;

    public CustomerCreatedEvent(Customer customer) {
        super(customer);
        this.customer = customer;
    }

    public Customer getCustomer() {
        return customer;
    }
}