package com.cognizant.customer_service.event;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class CustomerEventListener {

    @EventListener
    public void onCustomerCreated(CustomerCreatedEvent event) {
        System.out.println("New customer created: " + event.getCustomer().getFirstName());
    }
}
