package com.cognizant.item_service.event;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class ItemEventListener {

    @EventListener
    public void onItemCreated(ItemCreatedEvent event) {
        System.out.println("New item created: " + event.getItem().getName());
    }
}
