package com.cognizant.salesorder_service.event;


import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;


@Component
public class SalesOrderEventListener implements ApplicationListener<SalesOrderCreatedEvent> {

    @Override
    public void onApplicationEvent(SalesOrderCreatedEvent event) {
        System.out.println("Sales Order Created Event Received!");
        System.out.println("Sales Order ID: " + event.getSalesOrder().getId());
        System.out.println("Customer Name: " + event.getSalesOrder().getCustomerName());
        System.out.println("Product: " + event.getSalesOrder().getProduct());
        System.out.println("Quantity: " + event.getSalesOrder().getQuantity());
        System.out.println("Total Amount: " + event.getSalesOrder().getTotalAmount());
    }
}