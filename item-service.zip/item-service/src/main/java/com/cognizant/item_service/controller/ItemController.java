package com.cognizant.item_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.item_service.model.Item;
import com.cognizant.item_service.service.ItemService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/item")
public class ItemController {

	@Autowired
    private ItemService itemService;

    @GetMapping("/{itemname}")
    public Item getItemByName(@PathVariable String itemname) {
        return itemService.getItemByName(itemname);
    }

    @PostMapping
    public Item createItem(@RequestBody Item item) {
    	System.out.println("itemname: "+item.getName());
        return itemService.saveItem(item);
    }
}