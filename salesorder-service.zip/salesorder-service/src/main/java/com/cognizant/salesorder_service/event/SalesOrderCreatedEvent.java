package com.cognizant.salesorder_service.event;

import org.springframework.context.ApplicationEvent;

import com.cognizant.salesorder_service.model.SalesOrder;

public class SalesOrderCreatedEvent extends ApplicationEvent {

    private final SalesOrder salesOrder;

    public SalesOrderCreatedEvent(SalesOrder salesOrder) {
        super(salesOrder); // Passing the source (SalesOrder) to the parent constructor
        this.salesOrder = salesOrder;
    }

    public SalesOrder getSalesOrder() {
        return salesOrder;
    }
}